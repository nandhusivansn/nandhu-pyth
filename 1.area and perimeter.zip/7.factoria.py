a=int(input("enter a number"))
for i in range(a-1,0,-1):
    a=a*i
print(a)
