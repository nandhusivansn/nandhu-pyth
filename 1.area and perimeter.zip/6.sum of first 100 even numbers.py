a=0
for i in range(2,202,2):
    a=a+i
print(a)
