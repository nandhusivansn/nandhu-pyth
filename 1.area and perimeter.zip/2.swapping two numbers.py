x,y=input("enter two numbers").split()
print(f"the first number is {x} and the second number is {y}")
temp=x
x=y
y=temp
print(f"after swaping the dirst number is {x} and second number is {y}")
