string=input("enter a string")
print(string[-1]+string[1:len(string)-1]+string[0])
