a=int(input("enter the number"))
n=int(input("enter the limit"))
for i in range(1,n+1):
    print(a*i)
    
