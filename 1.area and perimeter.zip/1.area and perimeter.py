radius=int(input("enter the radius of the circle"))
area=3.14*radius*radius
perimeter=2*3.14*radius
print(f"area of a circle is:{area}")
print(f"perimeter is :{perimeter}")
