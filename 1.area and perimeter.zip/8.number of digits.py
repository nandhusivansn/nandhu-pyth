n=int(input("enter the number"))
i=0
while(n!=0):
    n=n//10
    i=i+1
print(i)
